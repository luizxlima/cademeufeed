import React, { HTMLProps, useEffect, useRef } from 'react'
import Link from 'next/link'

import { useField } from '@unform/core'

import styles from './styles.module.scss'

interface InputProps extends HTMLProps<HTMLInputElement> {
  name: string
  label?: string
  link?: string
}

function Input({ name, label, link, ...rest }: InputProps) {
  const inputRef = useRef<HTMLInputElement>(null)

  const { fieldName, defaultValue, registerField, error } = useField(name)

  useEffect(() => {
    registerField({
      name: fieldName,
      ref: inputRef,
      getValue: ref => {
        return ref.current.value
      },
      setValue: (ref, value) => {
        ref.current.value = value
      },
      clearValue: ref => {
        ref.current.value = ''
      },
    })
  }, [fieldName, registerField])

  return (
    <div className={styles.inputContainer}>
      <span>
        {error}
      </span>

      {link && !error && (
        <Link href={link === 'Não é cadastrado?' ? '/cadastrar' : '/entrar'}>
          {link}
        </Link>
      )}

      {label && (
        <label htmlFor={name}>
          {label}
        </label>
      )}

      <input 
        id={name}
        ref={inputRef} 
        defaultValue={defaultValue}
        className={error && styles.inputError}
        {...rest}
      />

      {error && (
        <svg 
          width="14"
          height="14"
          viewBox="0 0 14 14"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path 
            d="M13 1L1 13"
            stroke="#D03333"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path 
            d="M1 1L13 13"
            stroke="#D03333"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
    </div>
  )
}

export default Input 