import React, { HTMLProps, useEffect, useRef } from 'react'

import { useField } from '@unform/core'

import styles from './styles.module.scss'

interface InputProps extends HTMLProps<HTMLInputElement> {
  name: string
  label?: string
  link?: string
}

function InputRadio({ name, label, link, ...rest }: InputProps) {
  const inputRef = useRef<HTMLInputElement>(null)

  const { fieldName, defaultValue, registerField, error } = useField(name)

  useEffect(() => {
    registerField({
      name: fieldName,
      ref: inputRef,
      getValue: ref => {
        return ref.current.value
      },
      setValue: (ref, value) => {
        ref.current.value = value
      },
      clearValue: ref => {
        ref.current.value = ''
      },
    })
  }, [fieldName, registerField])

  return (
    <label className={styles.inputRadioContainer}>
      <input
        id={name}
        ref={inputRef} 
        defaultValue={defaultValue}
        className={error && styles.inputError}
        type="checkbox"
        {...rest}
      />
      <span>Lembrar senha</span>
    </label>
  )
}

export default InputRadio 