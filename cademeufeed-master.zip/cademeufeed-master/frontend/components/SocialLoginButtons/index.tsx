import { useContext } from 'react'
import Image from 'next/image'

import { AuthContext } from '../../contexts/AuthContext'

import styles from './styles.module.scss'

type SocialLoginBtnProps = {
  type: string
}

function SocialLoginButtons({ type }:SocialLoginBtnProps ) {
  const { signInSocial, signUpSocial } = useContext(AuthContext)

  async function handleSignIn(provider: string) {
    if(type === 'signIn') {
      await signInSocial(provider)
    } else if (type === 'signUp') {
      await signUpSocial(provider)
    }
  }

  return (
    <div className={styles.socialButtonsLogin}>
      <button type="button" onClick={() => handleSignIn('linkedin')}>
        <Image 
          src="/images/icons/linkedin.svg"
          alt="linkedin icon"
          width={24} height={24} 
        />
        {
          type === 'signUp' 
          ? 'Cadastre-se com o Linkedin'
          : 'Entrar com o Linkedin'
        }
      </button>
      <button type="button" onClick={() => handleSignIn('google')}>
        <Image 
          src="/images/icons/google.svg"
          alt="linkedin icon"
          width={22} height={22}
        />
        {
          type === 'signUp' 
          ? 'Cadastre-se com o Google'
          : 'Entrar com o Google'
        }
      </button>
    </div>
  )
}

export default SocialLoginButtons