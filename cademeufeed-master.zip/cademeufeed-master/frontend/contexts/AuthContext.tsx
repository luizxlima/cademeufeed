import { createContext, useEffect, useState } from "react"
import Router from "next/router"

import { setCookie, parseCookies, destroyCookie } from 'nookies'

import { signin } from "next-auth/client"

import api from "../services/api"

type SignInCredentials = {
  email: string
  password: string
}

type SignUpCredentials = {
  name: string
  email: string
  password: string
}

type AuthContextData = {
  signInDefault: (credentials: SignInCredentials) => Promise<void>
  signUpDefault: (credentials: SignUpCredentials) => Promise<void>
  signInSocial: (provider: string) => Promise<void>
  signUpSocial: (provider: string) => Promise<void>
  isAuthenticated: boolean
  user: User | undefined
}

type AuthProviderProps = {
  children: React.ReactNode
}

type SignInResponseData = {
  data: {
    status: number
    login_token?: string
    login_token_expires_at?: string
    errors?: string[]
  }
}

type User = {
  email: string
}

export const AuthContext = createContext({} as AuthContextData)

export function AuthProvider({ children }: AuthProviderProps) {
  const [errors, setErrors] = useState([] as string[])

  const [user, setUser] = useState<User>()

  const isAuthenticated = !!user

  useEffect(() => {
    async function fetchUserAuthenticated() {
      const cookies = parseCookies()
      if(cookies['cade_dev_token']) {
        try {
          const token = { login_token: cookies['cade_dev_token']}
          const response = await api.post('auth/test', token)
          
          console.log(response.data)
        } catch(err) {
          signOut()
          alert(err)
        }
      }
    }

    fetchUserAuthenticated()
  }, [])

  function signOut() {
    destroyCookie(undefined, 'cade_dev_token')
    destroyCookie(undefined, 'cade_dev_token_expires_at')
    Router.push('/entrar')
  }

  async function signInDefault(credentials: SignInCredentials) {
    try {
      const response = await api.post('auth/login/default', credentials)

      const { data }: SignInResponseData = response  
      
      if(data?.errors) {
        setErrors(data?.errors)
        alert(data.errors[0])
        return
      }

      const user: User = { email: credentials.email }

      setUser(user)

      setCookie(undefined, 'cade_dev_token', 
        String(data?.login_token), {
        maxAge: 60 * 60 * 24 * 30, // 30 days
        path: '/'
      })

      setCookie(undefined, 'cade_dev_token_expires_at', 
        String(data?.login_token_expires_at), {
        maxAge: 60 * 60 * 24 * 30, // 30 days
        path: '/'
      })

      Router.push('/')
    } catch(err) {
      alert(err)
    }
  }

  async function signUpDefault(credentials: SignUpCredentials) {
    try {
      const response = await api.post('users/create/default', credentials)

      const { data }: SignInResponseData = response
 
      if(data?.errors) {
        setErrors(data?.errors)
        alert(data.errors[0])
        return
      }

    const user: User = {
        email: credentials.email
      }

      setUser(user)

      Router.push('/')
    } catch(err) {
      alert(err)
    }
  }

  console.log(process.env.SITE_URL)
  async function signInSocial(provider: string) {
  signin(provider, {callbackUrl: `http://cademeufeed.mayckon.com.br/loading?signIn=${provider}`})
  }

  async function signUpSocial(provider: string) {
  signin(provider, {callbackUrl: `http://cademeufeed.mayckon.com.br/loading?signUp=${provider}`})
  }

  return (
    <AuthContext.Provider value={{ 
      signInDefault,
      signUpDefault,
      signInSocial,
      signUpSocial,
      isAuthenticated,
      user 
    }}>
      {children}
    </AuthContext.Provider>
  )
}