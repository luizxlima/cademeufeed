export type LoginCredentials = {
  name: string
  email: string
  password: string
}