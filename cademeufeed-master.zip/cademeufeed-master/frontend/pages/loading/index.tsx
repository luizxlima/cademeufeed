import { useEffect, useState } from 'react'
import Router from 'next/router'

import { useSession } from "next-auth/client"

import { setCookie } from 'nookies'

import api from '../../services/api'

type SignInResponseData = {
  data: {
    status: number
    login_token?: string
    login_token_expires_at?: string
    errors?: string[]
  }
}

function SocialLoading() {
  const [session] = useSession()
  const [errors, setErrors] = useState<string[]>([])

  useEffect(() => {
    async function handleSocialAuthentication() {
      const providerSignIn = Router?.query.signIn
      const providerSignUp = Router?.query.signUp
      let token = null;

      if(session && providerSignIn) {
        try {
          if(providerSignIn === 'google') {
            token = { google_token: session?.accessToken }
          } else {
            token = { linkedin_code: session?.accessToken }
          }

          const response = await api.post(`auth/login/${providerSignIn}`, token)

          const { data }: SignInResponseData = response

          if(data?.errors) {
            setErrors(data?.errors)
            alert(data?.errors)
            Router.push('/entrar')
            return
          }

          setCookie(undefined, 'cade_dev_token', 
            String(data?.login_token), {
              maxAge: 60 * 60 * 24 * 30, // 30 days
              path: '/'
          })

          setCookie(undefined, 'cade_dev_token_expires_at', 
            String(data?.login_token_expires_at), {
            maxAge: 60 * 60 * 24 * 30, // 30 days
            path: '/'
          })
  
          Router.push('/')
        } catch (err) {
          alert(err)
        }
      }

      if(session && providerSignUp) {
        try {
          if(providerSignUp === 'google') {
            token = { google_token: session?.accessToken }
          } else {
            token = { linkedin_code: session?.accessToken }
          }
          
          const response = await api.post(`users/create/${providerSignUp}`, token)

          const { data }: SignInResponseData = response

          if(data?.errors) {
            setErrors(data?.errors)
            alert(data?.errors)
            Router.push('/entrar')
            return
          }

          setCookie(undefined, 'cade_dev_token', 
            String(data?.login_token), {
              maxAge: 60 * 60 * 24 * 30, // 30 days
              path: '/'
          })

          setCookie(undefined, 'cade_dev_token_expires_at', 
            String(data?.login_token_expires_at), {
            maxAge: 60 * 60 * 24 * 30, // 30 days
            path: '/'
          })
  
          Router.push('/')
        } catch (err) {
          alert(err)
        }
      }
    }

    handleSocialAuthentication()
  }, [session])

  return (
    <p>Loading</p>
  )
}

export default SocialLoading