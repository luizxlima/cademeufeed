import NextAuth from 'next-auth'
import Providers from 'next-auth/providers'

export default NextAuth({
  providers: [
    Providers.Google({
      clientId: process.env.GOOGLE_ID,
      clientSecret: process.env.GOOGLE_SECRET,
    }),
    Providers.LinkedIn({
      clientId: process.env.LINKEDIN_ID,
      clientSecret: process.env.LINKEDIN_SECRET,
    }),
  ],

  callbacks: {
    signIn: async (user, account, profile) => {
      return true
    },

    session: async (session, token) => {
      session.accessToken = token.accessToken
      return session
    },

    jwt: async(token, user, account, profile, isNewUser)  => {
      if (account?.accessToken) {
        token.accessToken = account.accessToken
      }
      return token
    }
  },
})