import type { AppProps } from 'next/app'

import { Provider } from 'next-auth/client'

import '../styles/globals.scss'
import { AuthProvider } from '../contexts/AuthContext'

function MyApp({ Component, pageProps }: AppProps) {
  return (
    <Provider session={pageProps.session}>
      <AuthProvider>
        <Component {...pageProps} />
      </AuthProvider>
    </Provider>
  )
}
export default MyApp
