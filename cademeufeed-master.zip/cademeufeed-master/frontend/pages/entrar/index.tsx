
import { useContext, useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'

import { FormHandles, SubmitHandler } from '@unform/core'
import { Form } from '@unform/web'

import * as Yup from 'yup'

import getValidationErrorsForm from '../../utils/getValidationErrorsForm'
import { AuthContext } from '../../contexts/AuthContext'

import Input from '../../components/Input'
import SocialLoginButtons from '../../components/SocialLoginButtons'

import styles from './styles.module.scss'

import { LoginCredentials } from '../../types/Login'

function Login() {
  const formRef = useRef<FormHandles>(null)

  const { signInDefault, isAuthenticated } = useContext(AuthContext)
 
  const [loading, setLoading] = useState(false)

   const handleSubmit: SubmitHandler<LoginCredentials> = 
    async (credentials: LoginCredentials) => {
    formRef.current?.setErrors({});

    setLoading(true);

    try {
      const schema = Yup.object().shape({
        'email': Yup.string().email('Digite um e-mail válido')
        .required('Campo obrigatório'),
        'password': Yup.string().required('Campo obrigatório'),
      });
      
      await schema.validate(credentials, {
        abortEarly: false,
      });

      await signInDefault(credentials)
      
      setLoading(false)
      
    } catch (err) {
      
      if (err instanceof Yup.ValidationError) {
        const errors = getValidationErrorsForm(err)
        formRef.current?.setErrors(errors);
      }

      setLoading(false)
    }
  }

  useEffect(() => {
      if(isAuthenticated) {
        console.log(isAuthenticated)
      }
  }, [isAuthenticated])

  return (
    <div className={styles.login}>
      <section className={styles.containerColumnOne}>
        <div className={styles.columnOne}>
          <h2>Entrar na minha conta</h2>
          <span>Oi! Sentimos sua falta!</span>

          <SocialLoginButtons type="signIn" />

          <div className={styles.lineDecorator}>
            <div />
            <span>ou</span>
            <div />
          </div>

          <Form ref={formRef} onSubmit={handleSubmit}>
            <Input 
              name="email"
              label="E-mail"
              link="Não é cadastrado?"
              placeholder="exemplo@gmail.com"
            />
            <Input 
              type="password"
              name="password"
              label="Senha"
              placeholder="Digite aqui sua senha"
            />
           
            <button 
              type="submit"
              className={styles.btnGradientYellow}
            >
              Entrar na minha conta
            </button>
          </Form>
        </div>
      </section>
      
      <section className={styles.containerColumnTwo}>
        <Link href="/">
          <a>
            <Image src="/images/icons/X.svg" width={24} height={24} alt="close button" />
          </a>
        </Link>

        <figure>
          <Image 
            src="/images/logo.svg"
            width={85}
            height={61} 
            alt="logo cade meu feedback"
          />
        </figure>

        <figure>
          <Image
            src="/images/login_illustration.svg"
            width={800}
            height={600} 
            alt="ilustração"
          />
        </figure>
      </section>
    </div>
  );
}

export default Login;