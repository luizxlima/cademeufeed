import axios from 'axios'
import { parseCookies } from 'nookies'

const cookies = parseCookies()

const api = axios.create({
  baseURL: 'https://cademeufeed.mayckon.com.br/api',
  // headers: {
  //   Authorization: `Bearer ${cookies['cade_dev_token']}`
  // }
})

export default api