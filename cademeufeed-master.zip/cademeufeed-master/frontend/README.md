## Frontend - Cade meu feedback NextJS

1 - Rodar o projeto em ambiente dev

```bash
#install all packages
yarn install
# run the project
yarn dev
```

