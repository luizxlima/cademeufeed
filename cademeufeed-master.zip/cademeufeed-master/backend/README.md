<h1>Backend Cadê meu Feed</h1>

<h2>Highlights</h2>

- Server: Apache
- Language: PHP
- Framework: Laravel
- Restful
- JSON

<h2>Servidor de Testes</h2>

<a href="https://cademeufeed.mayckon.com.br">https://cademeufeed.mayckon.com.br</a>

<h2>End Points</h2>

<h3>Registrar Conta (Padrão)</h3>

- URL: <code>/api/users/create/default</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "name": "Mayckon", "email": "contato@mayckon.com.br", "password": "senha123" }</code>

- Exemplos de Reposta:

<code>
	{
    "status": 0,
    "errors": [
        "O email fornecido já está sendo utilizado."
    ]
}</code>

<code>{
    "status": 1
}</code>

<h3>Registrar Conta (Google)</h3>

- URL: <code>/api/users/create/google</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "google_token": "eyJhbGciOiJSUzI1NiIsImtpZCI6IjdmNTQ4ZjY3MDg2OTBjMjExMjBiMGFiNjY4Y2FhMDc5YWNiYzJiMmYiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiYXpwIjoiNjgxNzQ3MjM2MDc4LWxpbnJvYWw2Z3QwYXA0ZHFiZThlb2kwbXZvbzRkaGk1LmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwiYXVkIjoiNjgxNzQ3MjM2MDc4LWxpbnJvYWw2Z3QwYXA0ZHFiZThlb2kwbXZvbzRkaGk1LmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwic3ViIjoiMTAyMzE2NzA4ODU4NTM1NDAyOTE5IiwiZW1haWwiOiJ6YXRoYW9AZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJnM09QZ0F0dm9kQmNlNldhTkNjNGlRIiwibmFtZSI6Ik1heWNrb24gQmVybmFyZGVzIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FBVFhBSndyTHBpakpOQlFPZU1aa3Y2Tzd0Znk4Ykpqdm5CQlh0a3BDb25rPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6Ik1heWNrb24iLCJmYW1pbHlfbmFtZSI6IkJlcm5hcmRlcyIsImxvY2FsZSI6InB0LUJSIiwiaWF0IjoxNjI2NzczOTk5LCJleHAiOjE2MjY3Nzc1OTksImp0aSI6ImUzNjcxZTY0ZDhiOTBkZTZkYzNmNjM2MTk0NTQwNzdkOTRhMTVhMzIifQ.d4YcFLfodErSTc4af_m0XssHjD9arqhfCnxyIYokzFZG-xUDLltL3050cvYEDzq4AKmpEK9LsTzV5gBvHSF_MBsBcxU9ZroWoUAexIBgYoaUc8sMbxF37mHBhkcCLYfvA4qqf2NHqC4UCu3yofSRXo_497yRLPvrKnWpBXY_9A6Y1LEFRZBKxv2ut2nJqLBKx2cYesCEmk-GIfzASzm4vROU083tU-FeO_hb50jflxfrvmRAgWEiclphMGNO3Qjj5eT7hcoXnDHXAGXR7B99InhQtq9pAPXBj4gBdDTlWqfZuYU23_uT1Q3oZEde_OQRvyZRPvsOmhdFz7KzYlSB2A" }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token do Google Inválido"
    ]
}</code>

<code>{
    "status": 1
}</code>

<h3>Registrar Conta (Linkedin)</h3>

- URL: <code>/api/users/create/linkedin</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "linkedin_code": "AQQfVfD1lo4I2Zk7AmVAdVlU4Qof2KPK86iNVlh8QtSZI-KI0cF2vteP47U9cfnJP_G3sShiFD77IqikR0Rj0mRdEOP9VV0T1-Aw6iB48Zq1i4vg_F0UUDRFHMUceBBqjc2E9VJ6DZZvuFrD9iilhWdd0VKmm81v6MSO9mV5MraFvI0wSFTCOrvIQDAP-IdGV4QIkf78NEbD_Vy-_2g" }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Código do Linkedin Inválido"
    ]
}</code>

<code>{
    "status": 1
}</code>

<h3>Autenticar Conta (Padrão)</h3>

- URL: <code>/api/auth/login/default</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "email": "contato@mayckon.com.br", "password": "senha123" }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Credenciais de autenticação inválida."
    ]
}</code>

<code>{
    "status": 1,
    "login_token": "eyJpdiI6IkdCeGozVkp2MHJkT2dLNTlsUmQ0M1E9PSIsInZhbHVlIjoiQmJsbTlndlc0bS9GVnNzNURka2ZHZHU5eUxZbDRRQ0hPSmJLdHgvQk1Ycz0iLCJtYWMiOiI1ZDU3YzhiZTllYWRhNzEwMjA4MmUyNGYwOTRlZGIwYzM0NGM4YTA2ZjdmNGZiODMyYmQ0MjgxODVkNDIxYzJlIn0=",
    "login_token_expires_at": "2021-07-21T14:22:30.516750Z"
}</code>

<h3>Autenticar Conta (Google)</h3>

- URL: <code>/api/auth/login/google</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "google_token": "eyJhbGciOiJSUzI1NiIsImtpZCI6IjdmNTQ4ZjY3MDg2OTBjMjExMjBiMGFiNjY4Y2FhMDc5YWNiYzJiMmYiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiYXpwIjoiNjgxNzQ3MjM2MDc4LWxpbnJvYWw2Z3QwYXA0ZHFiZThlb2kwbXZvbzRkaGk1LmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwiYXVkIjoiNjgxNzQ3MjM2MDc4LWxpbnJvYWw2Z3QwYXA0ZHFiZThlb2kwbXZvbzRkaGk1LmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwic3ViIjoiMTAyMzE2NzA4ODU4NTM1NDAyOTE5IiwiZW1haWwiOiJ6YXRoYW9AZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJQWFd6SjVzcnRaUlFXWFpvMjVrdE93IiwibmFtZSI6Ik1heWNrb24gQmVybmFyZGVzIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FBVFhBSndyTHBpakpOQlFPZU1aa3Y2Tzd0Znk4Ykpqdm5CQlh0a3BDb25rPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6Ik1heWNrb24iLCJmYW1pbHlfbmFtZSI6IkJlcm5hcmRlcyIsImxvY2FsZSI6InB0LUJSIiwiaWF0IjoxNjI2ODcwNjM0LCJleHAiOjE2MjY4NzQyMzQsImp0aSI6ImZmYTliNTc4YjQ0MmRlMTQ3ZjFkMTZiYWM5YTcxMzM3YWFjYWE0NWIifQ.EdLqO-xQYrO7YGADvA8D7hj8d3VRf2o0hT6JHq6aoSdAfG0x5_wE9igVetuzIu5Lv5v4lg2OytMEQTaDyYXvqw6FjU9cz2N9WsPoOe55GarFooF8rFhpIZCxBBL_4ByRLhZseqaE5HH_1e23vqYShK2w_7IG5Vsj0t9V_yjmdyMBQT6bFjyOBFS-zzIGCK7i4NvYjEtouc8lmpmsfllXQKISQ1KCYONzeL8tKcGIkO70u95BJgWGgKiO1OFgkZgbTpAePPuywn8MY6Y2Fit1CHsM_s0m0lOQbKodfyIuTJUR5QJiSMuJaeEUWYZJ_ZS1iiwj-9weGEcjp7aktdIYBQ" }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token do Google Inválido"
    ]
}</code>

<code>{
    "status": 1,
    "login_token": "eyJpdiI6IldxTWtOWmhPNVZ6akhac2NlRUdvUEE9PSIsInZhbHVlIjoieVRvWURMREhleFliNWZsNmdsVXJoVmhxTjAzYVdYeG8vQWhGZHc4THp3dz0iLCJtYWMiOiI1ZWY2YzYyMGU2ODdjZTRkOWU0ZTI0NDQ0NzI0YzY4NTllMGU2YTY0NTQzNDllY2Y1ZTYwODhmNjVhNjZhNzI2In0=",
    "login_token_expires_at": "2021-07-21T13:16:17.308495Z"
}</code>

<h3>Teste de Autenticação</h3>

- URL: <code>/api/auth/test</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "login_token": "eyJpdiI6IldxTWtOWmhPNVZ6akhac2NlRUdvUEE9PSIsInZhbHVlIjoieVRvWURMREhleFliNWZsNmdsVXJoVmhxTjAzYVdYeG8vQWhGZHc4THp3dz0iLCJtYWMiOiI1ZWY2YzYyMGU2ODdjZTRkOWU0ZTI0NDQ0NzI0YzY4NTllMGU2YTY0NTQzNDllY2Y1ZTYwODhmNjVhNjZhNzI2In0=" }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}</code>

<code>{
    "status": 1
}</code>

<h3>Autenticar Conta (Linkedin)</h3>

- URL: <code>/api/auth/login/Linkedin</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "linkedin_code": "AQTgjTQSK6aRTYTDyC_3a83xUVjuTVWgtdZ5jTORfLD53SPardGJG35MizvhNTwi8xvfVrbpGwRTa7omhGvJnICr9ugiaRG4rFR7Pu8PJjNfLO8bYTcZsY3ahXkxzBrJ-oi_uRqYAQ3nWh4r96yOffNxupSXEz4fub6DiBQH26hkmn1x5omGFtBzdNA_jXr8cxBhyN-RaIae7uT5vBY" }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Código do Linkedin Inválido"
    ]
}</code>

<code>{
    "status": 1,
    "login_token": "eyJpdiI6InArcCtFMkpEcXpxTzRRcDFIODBHK0E9PSIsInZhbHVlIjoiNUJmMzhpd3FmeTNHYS9CelJUNm1BY0wwenBqeW4xUkdySWRaSlhOQnVuZz0iLCJtYWMiOiI5YzZjMGM2YTIyMzU4MWM0M2I4MzQ0YjM3MWEzNzZkM2ZlNjYyMjhlMTg1OThkYTdiZDJhMGY4N2ZkN2M0Y2Q0In0=",
    "login_token_expires_at": "2021-07-22T15:05:16.708665Z"
}</code>

<h3>Teste de Autenticação</h3>

- URL: <code>/api/auth/test</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "login_token": "eyJpdiI6IldxTWtOWmhPNVZ6akhac2NlRUdvUEE9PSIsInZhbHVlIjoieVRvWURMREhleFliNWZsNmdsVXJoVmhxTjAzYVdYeG8vQWhGZHc4THp3dz0iLCJtYWMiOiI1ZWY2YzYyMGU2ODdjZTRkOWU0ZTI0NDQ0NzI0YzY4NTllMGU2YTY0NTQzNDllY2Y1ZTYwODhmNjVhNjZhNzI2In0=" }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}</code>

<code>{
    "status": 1
}</code>

<h3>Criar Empresa</h3>

- URL: <code>/api/companies/create</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "login_token": "eyJpdiI6IitES2ZDRC9MOWUzNFVjUnRPdU9ERlE9PSIsInZhbHVlIjoiOFdsM2hCdUVlV3dRYi9YOEpCUHBXdy9tV281dTBVczVrY1pvOTJCbDZXRT0iLCJtYWMiOiI4OWJjNmRlN2JiNDdjZDU0ZjI2NmVkN2Q0NDFkMzc0ODM1NGEwNmUzZWM0Zjc3NThiMmNiOTM1OTdmZmZlNWUxIn0=", "name": "Empresa Teste 5", "segment_id": "1", "about": "Essa empresa foi criada apenas para teste.", "photo_base64": "data:image/png;base64,iVBOR..." }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "A imagem precisa ser no formato png."
    ]
}</code>

<code>{
    "status": 1
}</code>

<h3>Listar/Buscar Empresa</h3>

- URL: <code>/api/companies/search</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "search": "Empres", "page": 1 }</code>

- Exemplos de Reposta:

<code>{
    "status": 1,
    "page": 1,
    "hasMorePages": false,
    "companies": [
        {
            "id": 1,
            "name": "Empresa Teste",
            "segment_id": 1,
            "about": "Essa empresa foi criada apenas para teste.",
            "photo_path": "/storage/i_1_K8lhJG.png",
            "created_at": "2021-07-23T13:55:03.000000Z",
            "updated_at": "2021-07-23T13:55:03.000000Z"
        },
        {
            "id": 2,
            "name": "Empresa Teste 2",
            "segment_id": 1,
            "about": "Essa empresa foi criada apenas para teste.",
            "photo_path": "/storage/i_2_F7D2Ha.png",
            "created_at": "2021-07-23T13:55:05.000000Z",
            "updated_at": "2021-07-23T13:55:05.000000Z"
        },
        {
            "id": 3,
            "name": "Empresa Teste 3",
            "segment_id": 1,
            "about": "Essa empresa foi criada apenas para teste.",
            "photo_path": "/storage/i_3_GWhQb5.png",
            "created_at": "2021-07-23T13:55:10.000000Z",
            "updated_at": "2021-07-23T13:55:10.000000Z"
        },
        {
            "id": 4,
            "name": "Empresa Teste 4",
            "segment_id": 1,
            "about": "Essa empresa foi criada apenas para teste.",
            "photo_path": "/storage/i_4_Lshoes.png",
            "created_at": "2021-07-23T13:55:15.000000Z",
            "updated_at": "2021-07-23T13:55:15.000000Z"
        },
        {
            "id": 5,
            "name": "Empresa Teste 5",
            "segment_id": 1,
            "about": "Essa empresa foi criada apenas para teste.",
            "photo_path": "/storage/i_5_yFuey4.png",
            "created_at": "2021-07-23T13:55:22.000000Z",
            "updated_at": "2021-07-23T13:55:22.000000Z"
        }
    ]
}</code>

<h3>Criar Empresa</h3>

- URL: <code>/api/companies/create</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "login_token": "eyJpdiI6IitES2ZDRC9MOWUzNFVjUnRPdU9ERlE9PSIsInZhbHVlIjoiOFdsM2hCdUVlV3dRYi9YOEpCUHBXdy9tV281dTBVczVrY1pvOTJCbDZXRT0iLCJtYWMiOiI4OWJjNmRlN2JiNDdjZDU0ZjI2NmVkN2Q0NDFkMzc0ODM1NGEwNmUzZWM0Zjc3NThiMmNiOTM1OTdmZmZlNWUxIn0=", "name": "Empresa Teste 5", "segment_id": "1", "about": "Essa empresa foi criada apenas para teste.", "photo_base64": "data:image/png;base64,iVBOR..." }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "A imagem precisa ser no formato png."
    ]
}</code>

<code>{
    "status": 1
}</code>

<h3>Solicitar Feedback</h3>

- URL: <code>/api/userFeedbackRequest/create</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "login_token": "eyJpdiI6IlVHU1UyMVNJN2phaWFuV1I1RHQzSGc9PSIsInZhbHVlIjoiYXJpSld1RGxoSkcwT1Bxc0tzanFVMjlyc21kYjlWUGdSNi9TU1gxNjJ0ST0iLCJtYWMiOiIzZmEzNzk0YTcwNDk2YzQ1NDNiOWJiYTkyMzBjOGEwY2JlZDk2N2JmMTU1YWYxYzRmN2E3OGMyZGE5NmYxYWY2In0=", "company_id": "1", "category": "1", "advertising_link": "http://asdasdasd", "advertising_print_base64": "data:image/png,iVBORw0KGgoA...", "rate": "1", "description": "Teste de descrição"  }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}</code>

<code>{
    "status": 1
}</code>

<h3>Listar/Buscar Usuário</h3>

- URL: <code>/api/users/search</code>
- Método: POST

- Exemplo de Requisição:

<code>{ "login_token": "eyJpdiI6Im1rRmxkemU4bE5DUE41Rk1kdlIzV2c9PSIsInZhbHVlIjoiNk9FdHA5KzdmclBzTUxkTkdRR3p4Sm1sMU1zbWVPK2NrSE5haGo4SVNMWT0iLCJtYWMiOiIyYmE1NzBjNGVhNTVkYmE4MGYyMjQwNmYwMTM4YjFmMmZmNmNjMzk3MjYyZWVlOThiNjU0YzU4NzI3YzMzZGM1In0=", "search": "", "page": 1 }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}}</code>

<code>{
    "status": 1,
    "page": 1,
    "hasMorePages": false,
    "users": [
        {
            "id": 1,
            "profile": 0,
            "name": "Mayckon",
            "email": "mayckon@agroconsult.com.br",
            "email_notifications": 0,
            "photo_path": null,
            "created_at": "2021-07-19T09:22:16.000000Z",
            "updated_at": "2021-07-19T09:22:16.000000Z"
        },
        {
            "id": 2,
            "profile": 0,
            "name": "Mayckon",
            "email": "contato@mayckon.com.br",
            "email_notifications": 0,
            "photo_path": null,
            "created_at": "2021-07-19T09:23:47.000000Z",
            "updated_at": "2021-07-29T11:17:17.000000Z"
        },
        {
            "id": 4,
            "profile": 1,
            "name": "Mayckon",
            "email": "teste@mayckon.com.br",
            "email_notifications": 0,
            "photo_path": null,
            "created_at": "2021-07-21T13:48:29.000000Z",
            "updated_at": "2021-07-21T13:48:29.000000Z"
        },
        {
            "id": 5,
            "profile": 1,
            "name": "Mayckon Bernardes",
            "email": "zathao@gmail.com",
            "email_notifications": 0,
            "photo_path": null,
            "created_at": "2021-07-22T14:30:15.000000Z",
            "updated_at": "2021-07-22T14:39:02.000000Z"
        }
    ]
}</code>

<h3>Editar Usuário</h3>

- URL: <code>/api/users/edit</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "login_token": "eyJpdiI6Ill2OEtqRFJCRE5TR2ZMTGQySVY4eEE9PSIsInZhbHVlIjoiaXpJQWFxUFc1NUZZV3J4NkJiWHJCU0xhN0tCTkxzQ3R0RzNNbGVjOU4yRT0iLCJtYWMiOiJkYzc5OTc0MmIxOTVhZDFkNTdlZWQ1NjIxNWQwMjNmYWIxMWMwYmE4MjM4ZTRiNTRhZTExODcyMGM2ZDZjNGFlIn0=", "user_id": 2, "new_name": "Mayckon Bernardes", "new_profile": 0, "new_password": "123", "new_email_notifications": 0, "new_company_id": 2, "new_photo_base64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACkklEQVR4AX2TA8w0VxiFn3tnZvdbo7Zt27Ztu1HNoI7boIpr27Zta5391hjezhv9/ic5ycl7nmfCy0K+1YArKFmvsnq2LpEuN2Rb7CfQ1kt3Nrz5MHPqSzeaqz+710iky002YeYWNACgcLhn6fM3v/miOy4tXn7MGRy41uZsUlxOIh25ySaMsOLM/YPLlj1rozNPOPNI1kzmqXV+54/uz/w3+Z2K9wd/xl1usgkjrDgAGlg1vW35mh2P2pqMO6U2+oOeW2FCnT+//o4vn/qIYVSl71VkEwZhxRFXozlutUNWzpYd6Lv/4YZ1fNNg6lb46bkf+fPd36h9/zuh3ZRNGMoJEEdcO7l0cu/l1kpj/DYhAZoIewb+fXNMesmQjU7M8cOjVUprF0FpQqMwns1ya6f5LXZ1eklng3w+QJlZLN0hYXdQbpu/Xx+SKoZ4nSGjRkDj0zapdAcdM8LmcwHiaktDxnFxdJ+kNSCX6dP4eMJMOqBQGuD+N2C1Laf8+7aPNe2TcgYIK46twXbb/vdJ39s1lYnIJkLUwPDbyzl2PzcWt3AJPAU2PHdjgT9fMax72BiDhTdUTGNXKa2uPP6ulW9ab2uHVORjuRFuU7PKulMsZQCIlKLTdmjVHdIrR0y1w4+feNx/zr9XKWDVjfbJfnvW7Utnk75PLhGQTwc4ocHWBgA/VHhKMw4temMb13G45+Lm8NuXhxsBoBSXn35b2TzdWM28+Pfa5u3KqubTxorm69YKEulyi7e1hDHCigOgAYzhtvuv79z71kOzLFWyWbG0EktnVmep9GpIpK9YXineHIQRVpyFPqZ9jkx0Hn59WfNPdyMTmK0l0o3cZJv/MS3yOa++Jq/uvAv1XeJIX9Rz/h+220hISgvrLgAAAABJRU5ErkJggg==" }</code>

<code>{ "login_token": "eyJpdiI6Ill2OEtqRFJCRE5TR2ZMTGQySVY4eEE9PSIsInZhbHVlIjoiaXpJQWFxUFc1NUZZV3J4NkJiWHJCU0xhN0tCTkxzQ3R0RzNNbGVjOU4yRT0iLCJtYWMiOiJkYzc5OTc0MmIxOTVhZDFkNTdlZWQ1NjIxNWQwMjNmYWIxMWMwYmE4MjM4ZTRiNTRhZTExODcyMGM2ZDZjNGFlIn0=", "user_id": 2, "new_profile": 0 }</code>

<code>{ "login_token": "eyJpdiI6Ill2OEtqRFJCRE5TR2ZMTGQySVY4eEE9PSIsInZhbHVlIjoiaXpJQWFxUFc1NUZZV3J4NkJiWHJCU0xhN0tCTkxzQ3R0RzNNbGVjOU4yRT0iLCJtYWMiOiJkYzc5OTc0MmIxOTVhZDFkNTdlZWQ1NjIxNWQwMjNmYWIxMWMwYmE4MjM4ZTRiNTRhZTExODcyMGM2ZDZjNGFlIn0=", "user_id": 2, "new_name": "Mike", "new_profile": 0 }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}}</code>

<code>{
    "status": 1
}</code>

<h3>Perfil</h3>

- URL: <code>/api/profile</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "login_token": "eyJpdiI6Ik55WGdJdnd1YlcveUYrRzZKQWtXT2c9PSIsInZhbHVlIjoiNE1BaUFUcExHbnlJVzdWUWl2TmVMNkJSUm44b1VnOUwxSUdoUW9iNDJ3MD0iLCJtYWMiOiJlOWU1MDQ0MGE4YmE4MDEwMzJmOTk5NWNjZGEzNTZjODcyYzE5NjY3ODEyNGE3OGZjNTJiNjAzNjI1NDgzNWFmIn0=" }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}}</code>

<code>{
    "id": 1,
    "profile": 0,
    "name": "Mayckon",
    "email": "mayckon@agroconsult.com.br",
    "email_notifications": 0,
    "photo_path": null,
    "created_at": "2021-07-19T09:22:16.000000Z",
    "updated_at": "2021-08-03T20:19:23.000000Z"
}</code>

<h3>Editar Perfil</h3>

- URL: <code>/api/profile/edit</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "login_token": "eyJpdiI6Ik55WGdJdnd1YlcveUYrRzZKQWtXT2c9PSIsInZhbHVlIjoiNE1BaUFUcExHbnlJVzdWUWl2TmVMNkJSUm44b1VnOUwxSUdoUW9iNDJ3MD0iLCJtYWMiOiJlOWU1MDQ0MGE4YmE4MDEwMzJmOTk5NWNjZGEzNTZjODcyYzE5NjY3ODEyNGE3OGZjNTJiNjAzNjI1NDgzNWFmIn0=", "new_name": "Testeeeee Name", "new_password": "1234", "new_email_notifications": 0, "new_photo_base64": "..." }</code>

<code>{ "login_token": "eyJpdiI6Ik55WGdJdnd1YlcveUYrRzZKQWtXT2c9PSIsInZhbHVlIjoiNE1BaUFUcExHbnlJVzdWUWl2TmVMNkJSUm44b1VnOUwxSUdoUW9iNDJ3MD0iLCJtYWMiOiJlOWU1MDQ0MGE4YmE4MDEwMzJmOTk5NWNjZGEzNTZjODcyYzE5NjY3ODEyNGE3OGZjNTJiNjAzNjI1NDgzNWFmIn0=", "new_name": "Testeeeee Name" }</code>

<code>{ "login_token": "eyJpdiI6Ik55WGdJdnd1YlcveUYrRzZKQWtXT2c9PSIsInZhbHVlIjoiNE1BaUFUcExHbnlJVzdWUWl2TmVMNkJSUm44b1VnOUwxSUdoUW9iNDJ3MD0iLCJtYWMiOiJlOWU1MDQ0MGE4YmE4MDEwMzJmOTk5NWNjZGEzNTZjODcyYzE5NjY3ODEyNGE3OGZjNTJiNjAzNjI1NDgzNWFmIn0=", "new_password": "1234" }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}}</code>

<code>{
    "status": 1
}</code>

<h3>Listar/Buscar Solicitações de Feedback</h3>

- URL: <code>/api/userFeedbackRequest/search</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "login_token": "eyJpdiI6InU3a05YMWd6SGpVTVcyTnkzbnBnT1E9PSIsInZhbHVlIjoiR1RVakVnMjI3RExQRGJqUkx5SzR4UWtZSjdQeFY1bm1CckUvSlpRdStMUT0iLCJtYWMiOiIyNDNiOTU0OWFiMzk0YmYzY2VlZjc1Njg0YzgxYzNkNTBkNzQ2MTQxMjA0NGVmMjkwNWY1ZGRiYTMxYjMzOWJjIn0=", "search": "", "page": 1 }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}}</code>

<code>{
    "status": 1,
    "page": 1,
    "hasMorePages": false,
    "feedbacks": [
        {
            "id": 1,
            "user_id": 1,
            "company_id": 1,
            "category": 1,
            "advertising_link": "http://asdasdasd",
            "advertising_print_path": null,
            "rate": 1,
            "description": "Teste de descrição",
            "created_at": "2021-07-27T04:00:41.000000Z",
            "updated_at": "2021-07-27T04:00:41.000000Z"
        },
        {
            "id": 2,
            "user_id": 2,
            "company_id": 3,
            "category": 1,
            "advertising_link": null,
            "advertising_print_path": null,
            "rate": 1,
            "description": "Teste de descrição",
            "created_at": "2021-07-27T04:10:13.000000Z",
            "updated_at": "2021-07-27T04:10:13.000000Z"
        },
        {
            "id": 3,
            "user_id": 2,
            "company_id": 3,
            "category": 1,
            "advertising_link": "http://asdasdasd",
            "advertising_print_path": "/storage/f_3_fyNQqc.png",
            "rate": 1,
            "description": "Teste de descrição",
            "created_at": "2021-07-27T04:10:46.000000Z",
            "updated_at": "2021-07-27T04:10:47.000000Z"
        }
    ]
}</code>

<h3>Comentar Feedback</h3>

- URL: <code>/api/userFeedbackRequestComments/create</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "login_token": "eyJpdiI6IldINURxOHY4YXJRSmRMcEtXYnVuNUE9PSIsInZhbHVlIjoiNXJpODJFTEZ0cUZUMzVzWEwvemppTFozV3NJRmRUeUdJaW1qT01ZUGcxbz0iLCJtYWMiOiIxNjUzOTc2ZWVhZDY2NWU1NzZlNWRiNDI3YzkyZmRjMzQ0MDBkNmY0Y2E0MmVkMGYyMWM5ZTg2NGIwMGRhMzQ3In0=", "feedback_id": 1, "text": "Comentário de teste." }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}}</code>

<code>{
    "status": 1
}</code>

<h3>Listar/Buscar Comentários dos Feedbacks</h3>

- URL: <code>/api/userFeedbackRequestComments/search</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "login_token": "eyJpdiI6IldINURxOHY4YXJRSmRMcEtXYnVuNUE9PSIsInZhbHVlIjoiNXJpODJFTEZ0cUZUMzVzWEwvemppTFozV3NJRmRUeUdJaW1qT01ZUGcxbz0iLCJtYWMiOiIxNjUzOTc2ZWVhZDY2NWU1NzZlNWRiNDI3YzkyZmRjMzQ0MDBkNmY0Y2E0MmVkMGYyMWM5ZTg2NGIwMGRhMzQ3In0=", "feedback_id": 1 }</code>

<code>{ "login_token": "eyJpdiI6IldINURxOHY4YXJRSmRMcEtXYnVuNUE9PSIsInZhbHVlIjoiNXJpODJFTEZ0cUZUMzVzWEwvemppTFozV3NJRmRUeUdJaW1qT01ZUGcxbz0iLCJtYWMiOiIxNjUzOTc2ZWVhZDY2NWU1NzZlNWRiNDI3YzkyZmRjMzQ0MDBkNmY0Y2E0MmVkMGYyMWM5ZTg2NGIwMGRhMzQ3In0=", "feedback_id": 1, "search": "" }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}}</code>

<code>{
    "status": 1,
    "page": 1,
    "hasMorePages": false,
    "comments": [
        {
            "id": 3,
            "user_feedback_request_id": 1,
            "text": "Comentário de teste.",
            "user_id": 1,
            "created_at": "2021-08-04T16:03:50.000000Z",
            "updated_at": "2021-08-04T16:03:50.000000Z"
        },
        {
            "id": 2,
            "user_feedback_request_id": 1,
            "text": "Comentário de teste.",
            "user_id": 1,
            "created_at": "2021-08-04T14:07:24.000000Z",
            "updated_at": "2021-08-04T14:07:24.000000Z"
        },
        {
            "id": 1,
            "user_feedback_request_id": 1,
            "text": "Comentário de teste.",
            "user_id": 1,
            "created_at": "2021-08-04T14:05:41.000000Z",
            "updated_at": "2021-08-04T14:05:41.000000Z"
        }
    ]
}</code>

<h3>Avaliar Empresa</h3>

- URL: <code>/api/companyEvaluation/create</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "login_token": "eyJpdiI6IldINURxOHY4YXJRSmRMcEtXYnVuNUE9PSIsInZhbHVlIjoiNXJpODJFTEZ0cUZUMzVzWEwvemppTFozV3NJRmRUeUdJaW1qT01ZUGcxbz0iLCJtYWMiOiIxNjUzOTc2ZWVhZDY2NWU1NzZlNWRiNDI3YzkyZmRjMzQ0MDBkNmY0Y2E0MmVkMGYyMWM5ZTg2NGIwMGRhMzQ3In0=", "anonymous": false, "title": "Teste", "company_id": "1", "category": "1", "difficulty": "1", "advertising_link": "http://asdasdasd", "advertising_print_base64": "data:image/png,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACQUlEQVR4AW1SA6xcQRR9Qe2oduwsa9sNan17a9u2g9q2bXzbf23bt3Mnea+rm4znnKvDJDJeVklLXlbRUF5mQRIvMz+Zl/lnuCjtfeu0tLSE/yOBbXlZpft4uVVWwQoVzNwphfn76kGwQgm8nHIrP/PPeXHa616JiBDchZddVj1xmxpufXGB0uAFuytAh8Hqh9f5Vpi9nxBlFRoGp78YEUGC4OK2vOzS6tRTRiiXOkGm88KJh2rQEyDu2bPZEYD1F1VIYhyWfL0rR0LyPYSev5XboKDWST+zxp6dniA9Y2TzDihAkPHtPCFozpAitcT8jj02wqt8cxTYaPNznln7WWmHAw+dQNJ1TEg61gcJhg5YKaUfI8Eak4+edRY/sHb3s56CcQiWK2BQ6tN5SJA0aas8AoxhUjBdWWOB7BCtMcDg9JdbkCB5zCYVvMh3AmtnXthhzfX/ngul8QRiQjAk/cU2BkUiJH0etycIxdIwB1pxLQR5lyAhyYidQLUxNPVeKoMKwyJO2BuECfuCUCrnSJAgjgTP5C8W0Tk9aRefwV4ShR2ZtE0J6WfMdNSqufDp+chjO3d+8scN+Fec/uEmwXZl0Ig8Owmy8+tzT0lhy1U1HVKdDwd3vvTWCGiH76lBkPVXMS15z2CqAzSMYnDa0/7C7PyGtCN15JMGjtzXRg56h2/CrD+KqalHJhFMe06JLAnKExU2bHmRY9G+CpCcrqcD98OWFTkxbPQcB44kwbBQYSgS7DO2CquNBcOc8T0S/A8fCHW8HLTNsgAAAABJRU5ErkJggg==", "rate": "1", "description": "Teste de descrição"  }</code>

- Exemplos de Reposta:

<code>{
    "status": 0,
    "errors": [
        "Token de autenticação inválido."
    ]
}}</code>

<code>{
    "status": 1
}</code>

<h3>Listar/Buscar Avaliações de Empresa</h3>

- URL: <code>/api/companyEvaluation/search</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "search": "" }</code>

- Exemplos de Reposta:

<code>{
    "status": 1,
    "page": 1,
    "hasMorePages": false,
    "evaluations": [
        {
            "id": 2,
            "user_id": 1,
            "company_id": 1,
            "anonymous": 0,
            "title": "Teste",
            "category": 1,
            "difficulty": null,
            "advertising_link": "http://asdasdasd",
            "advertising_print_path": "/storage/e_2_9r8VuJ.png",
            "rate": 1,
            "description": "Teste de descrição",
            "created_at": "2021-08-04T16:10:48.000000Z",
            "updated_at": "2021-08-04T16:10:48.000000Z"
        },
        {
            "id": 1,
            "user_id": 1,
            "company_id": 1,
            "anonymous": 0,
            "title": "Teste",
            "category": 1,
            "difficulty": null,
            "advertising_link": "http://asdasdasd",
            "advertising_print_path": "/storage/e_1_pjsFJg.png",
            "rate": 1,
            "description": "Teste de descrição",
            "created_at": "2021-08-04T16:10:21.000000Z",
            "updated_at": "2021-08-04T16:10:21.000000Z"
        }
    ]
}</code>

<h3>Dar Like nas Avaliações de Empresa</h3>

- URL: <code>/api/companyEvaluationLikes/create</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "login_token": "eyJpdiI6IktZdjNwcTZyVER3d1p6RXlwYXd5UFE9PSIsInZhbHVlIjoiNG9EQW04cWNXTnFGanR5cEZ5TEVkTFdCS3ZMTzhFMmlKWW1mLzZDaktCND0iLCJtYWMiOiJlMzMyNTUxODU0YzRkNGNiZWIyMzAxMmMwMWFlZjJiZDgwZmEyZTllM2VmMDRkNGJjNTYzZDAxYjcxMjczZTI3In0=", "company_evaluation_id": 2 }</code>

- Exemplos de Reposta:

<code>{
    "status": 1
}</code>

<h3>Remover Like nas Avaliações de Empresa</h3>

- URL: <code>/api/companyEvaluationLikes/delete</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "login_token": "eyJpdiI6IktZdjNwcTZyVER3d1p6RXlwYXd5UFE9PSIsInZhbHVlIjoiNG9EQW04cWNXTnFGanR5cEZ5TEVkTFdCS3ZMTzhFMmlKWW1mLzZDaktCND0iLCJtYWMiOiJlMzMyNTUxODU0YzRkNGNiZWIyMzAxMmMwMWFlZjJiZDgwZmEyZTllM2VmMDRkNGJjNTYzZDAxYjcxMjczZTI3In0=", "company_evaluation_id": 2 }</code>

- Exemplos de Reposta:

<code>{
    "status": 1
}</code>

<h3>Mostrar Empresa</h3>

- URL: <code>/api/companies/get/{company_id}</code>
- Método: GET

- Exemplos de Requisição:

<code>/api/companies/get/1</code>

- Exemplos de Reposta:

<code>{
    "status": 1,
    "company": {
        "id": 1,
        "name": "Empresa Teste",
        "segment_id": 1,
        "about": "Essa empresa foi criada apenas para teste.",
        "photo_path": null,
        "created_at": "2021-07-23T01:28:51.000000Z",
        "updated_at": "2021-07-23T01:28:51.000000Z",
        "rate": "1.0000",
        "evaluations": [
            {
                "id": 1,
                "user_id": 1,
                "company_id": 1,
                "anonymous": 0,
                "title": "Teste",
                "category": 1,
                "difficulty": null,
                "advertising_link": "http://asdasdasd",
                "advertising_print_path": "/storage/e_1_pjsFJg.png",
                "rate": 1,
                "description": "Teste de descrição",
                "created_at": "2021-08-04T16:10:21.000000Z",
                "updated_at": "2021-08-04T16:10:21.000000Z"
            }
        ],
        "categoriesRatesAverage": [
            "1.0000",
            null,
            null,
            null
        ]
    }
}</code>

<h3>Estatísticas de Feedback</h3>

- URL: <code>/api/feedbackStats</code>
- Método: GET

- Exemplos de Requisição:

<code>/api/feedbackStats</code>

- Exemplos de Reposta:

<code>{
    "status": 1,
    "total_feedback_requests": 3,
    "total_feedback_requests_answered_by_company": 2,
    "total_company_evaluations": 2
}</code>

<h3>Ranking de Empresas</h3>

- URL: <code>/api/companies/rank/{limit}</code>
- Método: GET

- Exemplos de Requisição:

<code>/api/companies/rank/2</code>

- Exemplos de Reposta:

<code>{
    "status": 1,
    "bestCompanies": [
        {
            "id": 5,
            "name": "Empresa Teste 5",
            "segment_id": 1,
            "about": "Empresta criada para teste",
            "photo_path": "/storage/i_5_rE8VZO.png",
            "created_at": "2021-12-15T06:56:50.000000Z",
            "updated_at": "2021-12-15T06:56:50.000000Z",
            "rate": "4.0000"
        },
        {
            "id": 6,
            "name": "Empresa Teste 6",
            "segment_id": 1,
            "about": "Empresta criada para teste",
            "photo_path": "/storage/i_6_RkcuuE.png",
            "created_at": "2021-12-15T06:56:54.000000Z",
            "updated_at": "2021-12-15T06:56:54.000000Z",
            "rate": "3.3333"
        }
    ],
    "worstCompanies": [
        {
            "id": 3,
            "name": "Cade meu feedback",
            "segment_id": 1,
            "about": "Solução em Feedback e Candidate Experience para Recrutamentos no BRASIL! ",
            "photo_path": "/storage/i_3_t9vOV4.png",
            "created_at": "2021-09-20T17:57:42.000000Z",
            "updated_at": "2021-09-20T17:57:42.000000Z",
            "rate": 0
        },
        {
            "id": 7,
            "name": "Empresa Teste 8",
            "segment_id": 1,
            "about": "Empresta criada para teste",
            "photo_path": "/storage/i_7_F3W1AE.png",
            "created_at": "2021-12-15T06:57:51.000000Z",
            "updated_at": "2021-12-15T06:57:51.000000Z",
            "rate": "1.0000"
        }
    ]
}</code>

<h3>Listar/Buscar Avaliações de Empresa Criadas pelo Usuário Autenticado</h3>

- URL: <code>/api/userCompanyEvaluation/search</code>
- Método: POST

- Exemplos de Requisição:

<code>{ "search": "" }</code>

- Exemplos de Reposta:

<code>{
    "status": 1,
    "page": 1,
    "hasMorePages": false,
    "evaluations": [
        {
            "id": 2,
            "user_id": 1,
            "company_id": 1,
            "anonymous": 0,
            "title": "Teste",
            "category": 1,
            "difficulty": null,
            "advertising_link": "http://asdasdasd",
            "advertising_print_path": "/storage/e_2_9r8VuJ.png",
            "rate": 1,
            "description": "Teste de descrição",
            "created_at": "2021-08-04T16:10:48.000000Z",
            "updated_at": "2021-08-04T16:10:48.000000Z"
        },
        {
            "id": 1,
            "user_id": 1,
            "company_id": 1,
            "anonymous": 0,
            "title": "Teste",
            "category": 1,
            "difficulty": null,
            "advertising_link": "http://asdasdasd",
            "advertising_print_path": "/storage/e_1_pjsFJg.png",
            "rate": 1,
            "description": "Teste de descrição",
            "created_at": "2021-08-04T16:10:21.000000Z",
            "updated_at": "2021-08-04T16:10:21.000000Z"
        }
    ]
}</code>
