<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AuthenticationController;

use App\Http\Controllers\UserController;
use App\Http\Controllers\ProfileController;

use App\Http\Controllers\CompanyController;
use App\Http\Controllers\CompanyEvaluationController;
use App\Http\Controllers\CompanyEvaluationLikesController;

use App\Http\Controllers\UserFeedbackRequestController;
use App\Http\Controllers\UserFeedbackRequestCommentsController;

use App\Http\Controllers\FeedbackStatsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Authentication
Route::post('/auth/login/default',[ AuthenticationController::class, "defaultLogin" ] )
    ->middleware( "json" )
    ->name( "auth.login.default" );

Route::post('/auth/login/google',[ AuthenticationController::class, "googleLogin" ] )
    ->middleware( "json" )
    ->name( "auth.login.google" );

Route::post('/auth/login/linkedin',[ AuthenticationController::class, "linkedinLogin" ] )
    ->middleware( "json" )
    ->name( "auth.login.linkedin" );

// Users
Route::post('/users/create/default',[ UserController::class, "defaultCreate" ] )
    ->middleware( "json" )
    ->name( "users.create.default" );

Route::post('/users/create/google',[ UserController::class, "googleCreate" ] )
    ->middleware( "json" )
    ->name( "users.create.google" );

Route::post('/users/create/linkedin',[ UserController::class, "linkedinCreate" ] )
    ->middleware( "json" )
    ->name( "users.create.linkedin" );

Route::post('/users/search',[ UserController::class, "search" ] )
    ->middleware( "json", "loginToken", "admin" )
    ->name( "users.search" );

Route::post('/users/edit',[ UserController::class, "edit" ] )
    ->middleware( "json", "loginToken", "admin" )
    ->name( "users.edit" );

// Profile
Route::post('/profile',[ ProfileController::class, "index" ] )
    ->middleware( "json", "loginToken" )
    ->name( "profile" );

Route::post('/profile/edit',[ ProfileController::class, "edit" ] )
    ->middleware( "json", "loginToken" )
    ->name( "profile.edit" );

// Companies
Route::post('/companies/create',[ CompanyController::class, "create" ] )
    ->middleware( "json", "loginToken" )
    ->name( "companies.create" );

Route::post('/companies/search',[ CompanyController::class, "search" ] )
    ->middleware( "json" )
    ->name( "companies.search" );

Route::get('/companies/rank/{limit}',[ CompanyController::class, "rank" ] )
    ->name( "companies.rank" );

Route::get('/companies/get/{companyId}',[ CompanyController::class, "select" ] )
    ->name( "companies.select" );

// Company Evaluation
Route::post('/companyEvaluation/create',[ CompanyEvaluationController::class, "create" ] )
    ->middleware( "json", "loginToken" )
    ->name( "companies.evaluation.create" );

Route::post('/companyEvaluation/search',[ CompanyEvaluationController::class, "search" ] )
    ->middleware( "json" )
    ->name( "companies.evaluation.search" ); 

Route::post('/userCompanyEvaluation/search',[ CompanyEvaluationController::class, "userSearch" ] )
    ->middleware( "json", "loginToken" )
    ->name( "companies.evaluation.search" ); 

// Company Evaluation Likes 
Route::post('/companyEvaluationLikes/create',[ CompanyEvaluationLikesController::class, "create" ] )
    ->middleware( "json", "loginToken" )
    ->name( "companies.evaluation.likes.create" );

Route::post('/companyEvaluationLikes/delete',[ CompanyEvaluationLikesController::class, "delete" ] )
    ->middleware( "json", "loginToken" )
    ->name( "companies.evaluation.likes.delete" );    

// User Feedback Request
Route::post('/userFeedbackRequest/create',[ UserFeedbackRequestController::class, "create" ] )
    ->middleware( "json", "loginToken" )
    ->name( "feedback.create" );

Route::post('/userFeedbackRequest/search',[ UserFeedbackRequestController::class, "search" ] )
    ->middleware( "json", "loginToken" )
    ->name( "feedback.search" );    

// User Feedback Request Comments   
Route::post('/userFeedbackRequestComments/create',[ UserFeedbackRequestCommentsController::class, "create" ] )
    ->middleware( "json", "loginToken" )
    ->name( "feedback.comments.create" ); 

Route::post('/userFeedbackRequestComments/search',[ UserFeedbackRequestCommentsController::class, "search" ] )
    ->middleware( "json", "loginToken" )
    ->name( "feedback.comments.search" );

// Feedback Stats
Route::get('/feedbackStats',[ FeedbackStatsController::class, "index" ] )
    ->name( "feedback.stats" );

// Test
Route::post('/auth/test',function(){

    return response()->json([ "status" => 1 ]);

})->middleware( "json", "loginToken" );