<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyEvaluation extends Model
{
    use HasFactory;

    public function company()
    {

    	return $this->belongsTo(Company::class);

    }

    public function likes()
    {
        return $this->hasMany(CompanyEvaluationLike::class);
    }

    public function user()
    {

    	return $this->belongsTo(User::class);

    }

}
