<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

use App\Models\User;

class UserController extends Controller
{

  public function defaultCreate(Request $request){

    $data = json_decode( $request->getContent(), true );

    $rules = [

      'name' => 'required|min:3|max:255',
      'email' => 'required|min:3|max:255|email|unique:users,email',
      'password' => 'required|min:3|max:255'
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.',
      'email' => 'O atributo :attribute deve ser um e-mail válido',
      'unique' => 'O :attribute fornecido já está sendo utilizado.'
      
    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $user = new User();

    $user->name = $request->name;
    $user->email = $request->email;
    $user->password = Hash::make( $request->password );

    $user->profile = 1;
    
    $user->save();

    return response()->json([ "status" => 1 ]);

  }

  public function googleCreate(Request $request){

    $data = json_decode( $request->getContent(), true );

    if( !isset( $data[ "google_token" ] ) )
      return response()->json([ "status" => 0, "errors" => [ "O atributo google_token é obrigatório." ] ]);
  
    $google_token = $data[ "google_token" ];
    $googleData = Http::withHeaders(['Authorization' => "Bearer $google_token"])->get( "https://www.googleapis.com/oauth2/v3/userinfo" );

    if( isset( $googleData[ "error" ] ) )
      return response()->json([ "status" => 0, "errors" => [ "Token do Google Inválido" ] ]);

    $rules = [

      'name' => 'required',
      'email' => 'required|unique:users,email'
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'unique' => 'O :attribute já está sendo utilizado.'
      
    ];

    $data = [ "name" =>  $googleData[ "name" ], "email" =>  $googleData[ "email" ] ];
    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $user = new User();

    $user->name = $data["name"];
    $user->email = $data["email"];
   
    $user->profile = 1;
    $user->google = 1;
    
    $user->save();

    return response()->json([ "status" => 1 ]);

  }

  public function linkedinCreate(Request $request){

    $data = json_decode( $request->getContent(), true );

    if( !isset( $data[ "linkedin_code" ] ) )
      return response()->json([ "status" => 0, "errors" => [ "O atributo linkedin_code é obrigatório." ] ]);

    $linkedinToken = $data[ "linkedin_code" ];

    $url = "https://api.linkedin.com/v2/me";
    $linkedinData = Http::withHeaders(['Authorization' => "Bearer $linkedinToken"])->get($url);

    if( isset( $linkedinData[ "serviceErrorCode" ] ) )
      return response()->json([ "status" => 0, "errors" => [ "Token do Linkedin Inválido" ] ]);

    $firstName;

    foreach( $linkedinData["firstName"]["localized"] as $value ){

      $firstName = $value;

    }

    $lastName;

    foreach( $linkedinData["lastName"]["localized"] as $value ){

      $lastName = $value;

    }

    $name = $firstName . " " . $lastName;

    $url = "https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))";
    $linkedinData = Http::withHeaders(['Authorization' => "Bearer $linkedinToken"])->get($url);

    $email = $linkedinData["elements"][0]["handle~"]["emailAddress"];

    $rules = [

      'name' => 'required',
      'email' => 'required|unique:users,email'
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'unique' => 'O :attribute já está sendo utilizado.'
      
    ];

    $data = [ "name" => $name, "email" => $email ];
    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $user = new User();

    $user->name = $data["name"];
    $user->email = $data["email"];
   
    $user->profile = 1;
    $user->linkedin = 1;
    
    $user->save();

    return response()->json([ "status" => 1 ]);

  }

  public function search(Request $request){

    $data = json_decode( $request->getContent(), true );

    $rules = [

      'search' => 'min:1|max:255'
      
    ];

    $messages = [

      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.'

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $data["search"] = isset( $data["search"] ) ? $data["search"] : "";
    
    $users = User::orderBy( 'id', 'asc' )
          ->where('name', 'like', '%' . $data["search"] . '%')
          ->paginate(10);

    $response["status"] = 1;
    $response["page"] = $users->currentPage();
    $response["hasMorePages"] = $users->hasMorePages();
    $response["users"] = $users->items();

    return  response()->json($response);

  }

  public function edit(Request $request){

    $data = json_decode( $request->getContent(), true );

    $rules = [

      'user_id' => 'required|exists:users,id',

    ];

    if( isset( $data['new_name'] ) )
      $rules['new_name'] = 'min:3|max:255';

    if( isset( $data['new_profile'] ) )
      $rules['new_profile'] = 'integer';

    if( isset( $data['new_email_notifications'] ) )
      $rules['new_email_notifications'] = 'boolean';

    if( isset( $data['new_password'] ) )
      $rules['new_password'] = 'min:3|max:255';

    if( isset( $data['new_company_id'] ) )
      $rules['new_company_id'] = 'exists:companies,id';

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.',
      'boolean' => 'O atributo :attribute deve ser true or false',
      'exists' => 'O :attribute fornecido não existe.',
      'integer' => 'O :attribute precisa ser um número inteiro.'
      
    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    if( isset( $data['new_photo_base64'] ) ){

      try {
        
        $data["new_photo_base64"] = explode( ',', $data["new_photo_base64"] )[1];

        $image = base64_decode($data["new_photo_base64"]);
        $f = finfo_open();
        $result = finfo_buffer($f, $image, FILEINFO_MIME_TYPE);
        
        if( $result != 'image/png' && $result != 'image/jpg' && $result != 'image/jpeg' )
          return response()->json([ "status" => 0, "errors" => [ "A imagem precisa ser no formato png ou jpg." ] ]);
      
      } catch (\Throwable $e) {
      
        return response()->json([ "status" => 0, "errors" => [ "A imagem precisa ser no formato png ou jpg." ] ]);
      
      }

    }

    $user = User::findOrFail( $data["user_id"] );

    if( isset( $data['new_name'] ) )
      $user->name = $data['new_name'];

    if( isset( $data['new_profile'] ) )
      $user->profile = $data['new_profile'];
    
    if( isset( $data['new_email_notifications'] ) )
      $user->email_notifications = $data['new_email_notifications'];

    if( isset( $data['new_password'] ) )
      $user->password = Hash::make( $data["new_password"] );

    if( isset( $data['new_photo_base64'] ) ){

      $fileName = 'u_' . $user->id . "_" . Str::random(6);
      $extension = "png";

      Storage::disk('local')->put( $fileName .".". $extension,  $image);

      $path = "/storage/" . $fileName .".". $extension;
      
      $user->photo_path = $path; 

    }

    if( isset( $data['new_company_id'] ) ){

      $user->companies()->detach();
      $user->companies()->attach( $data['new_company_id'] );

    }

    $user->save();

    return response()->json([ "status" => 1 ]);

  }
  
}
