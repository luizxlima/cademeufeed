<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

use App\Models\User;
use App\Models\UserFeedbackRequest;
use App\Models\UserFeedbackRequestComment;


class UserFeedbackRequestCommentsController extends Controller
{

  public function create(Request $request){

    $user = User::findOrFail( $request->get('userId') );
    $data = json_decode( $request->getContent(), true );

    $rules = [

      'feedback_id' => 'required|exists:user_feedback_requests,id',
      "text" => 'required|max:1024',
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.',
      'exists' => 'O atributo :attribute não existe.',
      
    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $feedback = UserFeedbackRequest::find($data['feedback_id']);

    if( $feedback->user_id != $user->id && ( $user->companies()->count() == 0 || $feedback->company_id != $user->companies()->first()->id ) )

      return response()->json([ "status" => 0, "errors" => [ "O usuário autenticado não pode visualizar o feedback especificado."]]);

    $comment = new UserFeedbackRequestComment();
    
    $comment->user_id = $user->id;
    $comment->text = $data["text"];

    $feedback->comments()->save($comment);

    return response()->json([ "status" => 1 ]);

  }

  public function search(Request $request){

    $user = User::findOrFail( $request->get('userId') );
    $data = json_decode( $request->getContent(), true );

    $rules = [

      'feedback_id' => 'required|exists:user_feedback_requests,id',
      'search' => 'min:1|max:255'
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.'

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $feedback = UserFeedbackRequest::find($data['feedback_id']);

    if( $feedback->user_id != $user->id && ( $user->companies()->count() == 0 || $feedback->company_id != $user->companies()->first()->id ) )

      return response()->json([ "status" => 0, "errors" => [ "O usuário autenticado não pode visualizar o feedback especificado."]]);

    $data["search"] = isset( $data["search"] ) ? $data["search"] : "";

    $comments = UserFeedbackRequestComment::orderBy( 'id', 'asc' )
          ->where( 'text', 'like', '%' . $data["search"] . '%')->get(); 

    $response["status"] = 1;
    $response["comments"] = $comments;

    return  response()->json($response);

  }

}
