<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

use App\Models\User;

class ProfileController extends Controller
{

  public function index(Request $request){

    $response["status"] = 1;
    $response["user"] = User::findOrFail( $request->get('userId') );
    
    return $response;

  }

  public function edit(Request $request){

    $user = User::findOrFail( $request->get('userId') );
    $data = json_decode( $request->getContent(), true );

    $rules = [];

    if( isset( $data['new_name'] ) )
      $rules['new_name'] = 'min:3|max:255';

    if( isset( $data['new_password'] ) )
      $rules['new_password'] = 'min:3|max:255';

    if( isset( $data['new_email_notifications'] ) )
      $rules['new_email_notifications'] = 'boolean';

    $messages = [

      'boolean' => 'O atributo :attribute deve ser true or false',
      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.',
      
    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    if( isset( $data['new_photo_base64'] ) ){

      try {
        
        $data["new_photo_base64"] = explode( ',', $data["new_photo_base64"] )[1];

        $image = base64_decode($data["new_photo_base64"]);
        $f = finfo_open();
        $result = finfo_buffer($f, $image, FILEINFO_MIME_TYPE);
        
        if( $result != 'image/png' )
          return response()->json([ "status" => 0, "errors" => [ "A imagem precisa ser no formato png." ] ]);
      
      } catch (\Throwable $e) {
      
        return response()->json([ "status" => 0, "errors" => [ "A imagem precisa ser no formato png." ] ]);

      }

    }

    if( isset( $data['new_name'] ) )
      $user->name = $data['new_name'];

    if( isset( $data['new_email_notifications'] ) )
      $user->email_notifications = $data['new_email_notifications'];

    if( isset( $data['new_password'] ) )
      $user->password = Hash::make( $data["new_password"] );

    if( isset( $data['new_photo_base64'] ) ){

      $fileName = 'u_' . $user->id . "_" . Str::random(6);
      $extension = "png";

      Storage::disk('local')->put( $fileName .".". $extension,  $image);

      $path = "/storage/" . $fileName .".". $extension;
      
      $user->photo_path = $path; 

    }

    $user->save();

    return response()->json([ "status" => 1 ]);

  }
  
}
