<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

use App\Models\User;
use App\Models\UserFeedbackRequest;

class UserFeedbackRequestController extends Controller
{

  public function create(Request $request){

    $data = json_decode( $request->getContent(), true );

    $rules = [

      'company_id' => 'required|exists:companies,id',
      'category' => 'required|integer|min:1|max:5',
       "advertising_link" => "url",
      "rate"  => 'required|integer|min:1|max:5',
      "description" => 'required|max:1024',
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.',
      'exists' => 'O atributo :attribute não existe.',
      'integer' => 'O atributo deve ser um número inteiro.',
      'url' => 'O atributo :attribute deve ser uma url válida.',

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    if( isset( $data[ "advertising_print_base64" ] ) ){

      try {
      
        $data["advertising_print_base64"] = explode( ',', $data["advertising_print_base64"] )[1];

        $image = base64_decode($data["advertising_print_base64"]);
        $f = finfo_open();
        $result = finfo_buffer($f, $image, FILEINFO_MIME_TYPE);
        
        if( $result != 'image/png' )
          return response()->json([ "status" => 0, "errors" => [ "A imagem precisa ser no formato png." ] ]);
      
      } catch (\Throwable $e) {
      
        return response()->json([ "status" => 0, "errors" => [ "A imagem precisa ser no formato png." ] ]);

      }

    }

    $feedback = new UserFeedbackRequest();

    $feedback->user_id = $request->get('userId');
    $feedback->company_id = $data["company_id"];
    $feedback->category = $data["category"];
    $feedback->rate = $data["rate"];
    $feedback->description = $data["description"];

    $feedback->save();

    if( isset( $data["advertising_link"] ) )
       $feedback->advertising_link = $data["advertising_link"];

    if( isset( $data[ "advertising_print_base64" ] ) ){

      $fileName = 'f_' . $feedback->id . "_" . Str::random(6);
      $extension = "png";

      Storage::disk('local')->put( $fileName .".". $extension,  $image);

      $path = "/storage/" . $fileName .".". $extension;
      
      $feedback->advertising_print_path = $path; 

    }

    $feedback->save();

    return response()->json([ "status" => 1 ]);

  }

  public function search(Request $request){

    $user = User::findOrFail( $request->get('userId') );
    $data = json_decode( $request->getContent(), true );

    $rules = [

      'search' => 'min:1|max:255'
      
    ];

    $messages = [

      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.'

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $data["search"] = isset( $data["search"] ) ? $data["search"] : "";

    $feedbacks = UserFeedbackRequest::orderBy( 'id', 'desc' )
          ->where([

            [ 'user_id', '=', $user->id ],
            [ 'description', 'like', '%' . $data["search"] . '%' ]
            

          ]); 

    if( $user->companies()->count() > 0 ){

      $feedbacks = $feedbacks->orWhere([

          [ 'company_id', '=', $user->companies()->first()->id ],
          [ 'description', 'like', '%' . $data["search"] . '%' ]          

      ]);

    }

    $feedbacks = $feedbacks->paginate(10);

    $response["status"] = 1;
    $response["page"] = $feedbacks->currentPage();
    $response["hasMorePages"] = $feedbacks->hasMorePages();

    $feedbacks = $feedbacks->items();

    foreach( $feedbacks as $feedback ){

      $feedback->company = $feedback->company()->get();
      $feedback->user = $feedback->user()->get();
      $feedback->comments = $feedback->comments()->get();

    }

    $response["feedbacks"] = $feedbacks;

    return  response()->json($response);

  }

}
