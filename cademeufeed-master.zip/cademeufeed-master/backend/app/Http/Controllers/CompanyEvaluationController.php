<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

use App\Models\User;
use App\Models\CompanyEvaluation;

class CompanyEvaluationController extends Controller
{

  public function create(Request $request){

    $data = json_decode( $request->getContent(), true );

    $rules = [

      'company_id' => 'required|exists:companies,id',
      'anonymous' => 'required|boolean',
      'title' => 'required|min:4|max:1024',
      'category' => 'required|integer|min:1|max:4',
      "advertising_link" => "url",
      "rate"  => 'required|integer|min:1|max:5',
      "description" => 'required|max:1024',
      
    ];

    if( isset( $data[ "category" ] ) && $data[ "category" ] == 2 )
      $rules[ "difficulty" ] = "required|integer|min:0|max:2";

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.',
      'exists' => 'O atributo :attribute não existe.',
      'integer' => 'O atributo deve ser um número inteiro.',
      'url' => 'O atributo :attribute deve ser uma url válida.',

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    if( isset( $data[ "advertising_print_base64" ] ) ){

      try {
      
        $data["advertising_print_base64"] = explode( ',', $data["advertising_print_base64"] )[1];

        $image = base64_decode($data["advertising_print_base64"]);
        $f = finfo_open();
        $result = finfo_buffer($f, $image, FILEINFO_MIME_TYPE);
        
        if( $result != 'image/png' )
          return response()->json([ "status" => 0, "errors" => [ "A imagem precisa ser no formato png." ] ]);
      
      } catch (\Throwable $e) {
      
        return response()->json([ "status" => 0, "errors" => [ "A imagem precisa ser no formato png." ] ]);

      }

    }

    $evaluation = new CompanyEvaluation();

    $evaluation->user_id = $request->get('userId');
    $evaluation->company_id = $data["company_id"];
    $evaluation->anonymous = $data["anonymous"];
    $evaluation->title = $data["title"];
    $evaluation->category = $data["category"];

    if( $data[ "category" ] == 2 )
      $evaluation->difficulty = $data["difficulty"];

    $evaluation->rate = $data["rate"];
    $evaluation->description = $data["description"];

    $evaluation->save();

    if( isset( $data["advertising_link"] ) )
       $evaluation->advertising_link = $data["advertising_link"];

    if( isset( $data[ "advertising_print_base64" ] ) ){

      $fileName = 'e_' . $evaluation->id . "_" . Str::random(6);
      $extension = "png";

      Storage::disk('local')->put( $fileName .".". $extension,  $image);

      $path = "/storage/" . $fileName .".". $extension;
      
      $evaluation->advertising_print_path = $path; 

    }

    $evaluation->save();

    return response()->json([ "status" => 1 ]);

  }

  public function search(Request $request){

    $data = json_decode( $request->getContent(), true );

    $rules = [

      'search' => 'min:1|max:255'
      
    ];

    $messages = [

      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.'

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $data["search"] = isset( $data["search"] ) ? $data["search"] : "";

    $evaluations = CompanyEvaluation::orderBy( 'id', 'desc' )
      ->where([

        [ "title", 'like', '%' . $data["search"] . '%' ],
        [ "description", 'like', '%' . $data["search"] . '%' ],

      ])->paginate(10);

    $response["status"] = 1;
    $response["page"] = $evaluations->currentPage();
    $response["hasMorePages"] = $evaluations->hasMorePages();

    $evaluations = $evaluations->items();
    foreach( $evaluations as $evaluation ){

      $evaluation->user = $evaluation->user()->get();
      $evaluation->company = $evaluation->company()->get();
      $evaluation->likes = $evaluation->likes()->get();

    }

    $response["evaluations"] = $evaluations;

    return  response()->json($response);

  }

  public function userSearch(Request $request){

    $data = json_decode( $request->getContent(), true );

    $rules = [

      'search' => 'min:1|max:255'
      
    ];

    $messages = [

      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.'

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $data["search"] = isset( $data["search"] ) ? $data["search"] : "";

    $evaluations = CompanyEvaluation::orderBy( 'id', 'desc' )
      ->where([

        [ "user_id", '=', $request->get('userId') ],
        [ "title", 'like', '%' . $data["search"] . '%' ],
        [ "description", 'like', '%' . $data["search"] . '%' ],

      ])->paginate(10);

    $response["status"] = 1;
    $response["page"] = $evaluations->currentPage();
    $response["hasMorePages"] = $evaluations->hasMorePages();

    $evaluations = $evaluations->items();
    foreach( $evaluations as $evaluation ){

      $evaluation->user = $evaluation->user()->get();
      $evaluation->company = $evaluation->company()->get();
      $evaluation->likes = $evaluation->likes()->get();

    }

    $response["evaluations"] = $evaluations;

    return  response()->json($response);

  }

}
