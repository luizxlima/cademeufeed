<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

use App\Models\Company;
use App\Models\User;

class CompanyController extends Controller
{

  public function create(Request $request){

    $data = json_decode( $request->getContent(), true );

    $rules = [

      'name' => 'required|min:3|max:255|unique:companies,name',
      'about' => 'required|min:3|max:1024',
      'segment_id' => 'required|min:0|max:19',
      'photo_base64' => 'required',
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.',
      'exists' => 'O atributo :attribute não existe'

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    try {
      
      $data["photo_base64"] = explode( ',', $data["photo_base64"] )[1];

      $image = base64_decode($data["photo_base64"]);
      $f = finfo_open();
      $result = finfo_buffer($f, $image, FILEINFO_MIME_TYPE);
      
     if( $result != 'image/png' && $result != 'image/jpg' && $result != 'image/jpeg' )
      return response()->json([ "status" => 0, "errors" => [ "A imagem precisa ser no formato png ou jpg." ] ]);
      
    } catch (\Throwable $e) {
    
      return response()->json([ "status" => 0, "errors" => [ "A imagem precisa ser no formato png ou jpg." ] ]);
      
    }

    $company = new Company();

    $company->name = $data["name"];
    $company->segment_id = $data["segment_id"];
    $company->about = $data["about"];

    $company->save();

    $fileName = 'i_' . $company->id . "_" . Str::random(6);
    $extension = "png";

    Storage::disk('local')->put( $fileName .".". $extension,  $image);

    $path = "/storage/" . $fileName .".". $extension;
    
    $company->photo_path = $path; 
    $company->save();

    return response()->json([ "status" => 1, "company" => $company ]);

  }

  public function search(Request $request){

    $data = json_decode( $request->getContent(), true );

    $rules = [

      'search' => 'min:1|max:255'
      
    ];

    $messages = [

      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.'

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $data["search"] = isset( $data["search"] ) ? $data["search"] : "";

    $companies = Company::orderBy( 'id', 'asc' )
          ->where('name', 'like', '%' . $data["search"] . '%')
          ->paginate(10);

    $response["status"] = 1;
    $response["page"] = $companies->currentPage();
    $response["hasMorePages"] = $companies->hasMorePages();
    $response["companies"] = $companies->items();

    return  response()->json($response);

  }

  public function select($companyId){

    $data[ "company_id" ] = $companyId;

    $rules = [

      'company_id' => 'required|exists:companies,id',
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'exists' => 'O atributo :attribute não existe.',

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $company = Company::findOrFail($data["company_id"]);
 
    $categoriesRatesAverage = [

      $company->evaluations()->where('category','=',1)->avg('rate'),
      $company->evaluations()->where('category','=',2)->avg('rate'),
      $company->evaluations()->where('category','=',3)->avg('rate'),
      $company->evaluations()->where('category','=',4)->avg('rate'),

    ];

    $company->rate = $company->evaluations()->avg('rate');
    $company->evaluations = $company->evaluations()->get();

    foreach( $company->evaluations as $evaluation ){

      $evaluation->likes = $evaluation->likes()->get();

      if( !$evaluation->anonymous )
        $evaluation->user = User::findOrFail($evaluation->user_id);

    }

    $company->categoriesRatesAverage = $categoriesRatesAverage;

    $response["status"] = 1;
    $response["company"] = $company;

    return  response()->json($response);

  }

  public function rank(Request $request, $limit){

    $companies = Company::get();

    foreach( $companies as $company ){

      $company->rate = $company->evaluations()->avg('rate');
      $company->rate = $company->rate == null ? 0 : $company->rate;

    }

    for( $i=0; $i<count($companies)-1; $i++ ){
      for( $j=$i+1; $j<count($companies); $j++ ){

        if( $companies[$j]->rate > $companies[$i]->rate ){

          $tmpCompany = $companies[$i];

          $companies[$i] = $companies[$j];
          $companies[$j] = $tmpCompany;

        }

      }
    }
    
    $bestCompanies = $companies->all();

    while(count($bestCompanies) > $limit)
      array_pop($bestCompanies);


    $worstCompanies = $companies->all();

    while(count($worstCompanies) > $limit)
      array_shift($worstCompanies);

    for( $i=0; $i<count($worstCompanies)-1; $i++ ){
      for( $j=$i+1; $j<count($worstCompanies); $j++ ){

        if( $worstCompanies[$j]->rate < $worstCompanies[$i]->rate ){

          $tmpCompany = $worstCompanies[$i];

          $worstCompanies[$i] = $worstCompanies[$j];
          $worstCompanies[$j] = $tmpCompany;

        }

      }
    }

    $response["status"] = 1;
    $response["bestCompanies"] = $bestCompanies;
    $response["worstCompanies"] = $worstCompanies;

    return  response()->json($response);

  }

}
