<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

use App\Models\UserFeedbackRequest;
use App\Models\UserFeedbackRequestComments;
use App\Models\CompanyEvaluation;

class FeedbackStatsController extends Controller
{

  public function index(){


    $response[ "status" ] = 1;
    $response[ "total_feedback_requests" ] = UserFeedbackRequest::get()->count();

    $totalFeedbackRequestsAnswered = count( DB::select("SELECT DISTINCT f.id, f.user_id, c.user_id FROM user_feedback_request_comments as c LEFT JOIN user_feedback_requests as f ON c.user_feedback_request_id = f.id WHERE f.user_id <> c.user_id;") );
  
    $response[ "total_feedback_requests_answered_by_company" ] = $totalFeedbackRequestsAnswered;
    $response[ "total_company_evaluations"] = CompanyEvaluation::get()->count();

    return response()->json($response);

  }

}
