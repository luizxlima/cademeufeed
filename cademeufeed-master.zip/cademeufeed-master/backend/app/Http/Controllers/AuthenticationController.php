<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Crypt;

use App\Models\User;

class AuthenticationController extends Controller
{

  public function defaultLogin(Request $request){

    $data = json_decode( $request->getContent(), true );

    $rules = [

      'email' => 'required|min:3|max:255|email',
      'password' => 'required|min:3|max:255'
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',
      'min' => 'O atributo :attribute deve conter no mínimo :min caracteres.',
      'max' => 'O atributo :attribute não pode ter mais do que :max caracteres.',
      'email' => 'O atributo :attribute deve ser um e-mail válido.'

    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $user = User::where([ 

      [ "email", $data["email"] ], 
      [ "google", 0 ],
      [ "linkedin", 0 ]  

    ])->first();

    if( $user == null || !Hash::check( $data["password"], $user->password ) )
      return response()->json([ "status" => 0, "errors" => [ "Credenciais de autenticação inválida." ] ]);

    $loginToken = Crypt::encryptString( $user->id . "|" . now() );
    $loginTokenExpiresAt = now()->modify('+30 min');

    $user->login_token = $loginToken;
    $user->login_token_expires_at = $loginTokenExpiresAt;

    $user->save();

    return response()->json([ "status" => 1, "login_token" => $loginToken, "login_token_expires_at" => $loginTokenExpiresAt, "user" => $user ]);

  }

  public function googleLogin(Request $request){

    $data = json_decode( $request->getContent(), true );
     
    if( !isset( $data[ "google_token" ] ) )
      return response()->json([ "status" => 0, "errors" => [ "O atributo google_token é obrigatório." ] ]);

    $google_token = $data[ "google_token" ];
     $googleData = Http::withHeaders(['Authorization' => "Bearer $google_token"])->get( "https://www.googleapis.com/oauth2/v3/userinfo" );
     
    if( isset( $googleData[ "error" ] ) )
      return response()->json([ "status" => 0, "errors" => [ "Token do Google Inválido" ] ]); 

    $rules = [

      'email' => 'required'
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.'

    ];

    $data = [ "email" =>  $googleData[ "email" ] ];
    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $user = User::where([ 

      [ "email", $data["email"] ], 
      [ "google", 1 ]  

    ])->first();

    if( $user == null )
      return response()->json([ "status" => 0, "errors" => [ "Credenciais de autenticação inválida." ] ]);
 
    $loginToken = Crypt::encryptString( $user->id . "|" . now() );
    $loginTokenExpiresAt = now()->modify('+30 min');

    $user->login_token = $loginToken;
    $user->login_token_expires_at = $loginTokenExpiresAt;

    $user->save();

    return response()->json([ "status" => 1, "login_token" => $loginToken, "login_token_expires_at" => $loginTokenExpiresAt, "user" => $user ]);

  }

  public function linkedinLogin(Request $request){

    $data = json_decode( $request->getContent(), true );

    if( !isset( $data[ "linkedin_code" ] ) )
      return response()->json([ "status" => 0, "errors" => [ "O atributo linkedin_code é obrigatório." ] ]);

    $linkedinToken = $data[ "linkedin_code" ];

    $url = "https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))";
    $linkedinData = Http::withHeaders(['Authorization' => "Bearer $linkedinToken"])->get($url);

    if( isset( $linkedinData[ "serviceErrorCode" ] ) )
      return response()->json([ "status" => 0, "errors" => [ "Token do Linkedin Inválido" ] ]);

    $email = $linkedinData["elements"][0]["handle~"]["emailAddress"];

    $rules = [

      'email' => 'required'
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.'

    ];

    $data = [ "email" =>  $email ];
    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $user = User::where([ 

      [ "email", $data["email"] ], 
      [ "linkedin", 1 ]  

    ])->first();

    if( $user == null )
      return response()->json([ "status" => 0, "errors" => [ "Credenciais de autenticação inválida." ] ]);
 
    $loginToken = Crypt::encryptString( $user->id . "|" . now() );
    $loginTokenExpiresAt = now()->modify('+30 min');

    $user->login_token = $loginToken;
    $user->login_token_expires_at = $loginTokenExpiresAt;

    $user->save();

    return response()->json([ "status" => 1, "login_token" => $loginToken, "login_token_expires_at" => $loginTokenExpiresAt, "user" => $user ]);

  }
  
}
