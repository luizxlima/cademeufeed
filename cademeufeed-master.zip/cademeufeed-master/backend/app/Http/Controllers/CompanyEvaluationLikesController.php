<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

use App\Models\User;
use App\Models\CompanyEvaluation;
use App\Models\CompanyEvaluationLike;

class CompanyEvaluationLikesController extends Controller
{

  public function create(Request $request){

    $user = User::findOrFail( $request->get('userId') );
    $data = json_decode( $request->getContent(), true );

    $rules = [

      'company_evaluation_id' => 'required|exists:company_evaluations,id'
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',     
      'exists' => 'O atributo :attribute não existe.',
      
    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $evaluation = CompanyEvaluation::find($data['company_evaluation_id']);
    $evaluation->likes()->where("user_id",$user->id)->delete();

    $like = new CompanyEvaluationLike();    
    $like->user_id = $user->id;

    $evaluation->likes()->save($like);

    $evaluation->user = $evaluation->user()->get();
    $evaluation->company = $evaluation->company()->get();
    $evaluation->likes = $evaluation->likes()->get();

    return response()->json([ "status" => 1, "evaluation" => $evaluation ]);

  }

  public function delete(Request $request){

    $user = User::findOrFail( $request->get('userId') );
    $data = json_decode( $request->getContent(), true );

    $rules = [

      'company_evaluation_id' => 'required|exists:company_evaluations,id'
      
    ];

    $messages = [

      'required' => 'O atributo :attribute é obrigatório.',     
      'exists' => 'O atributo :attribute não existe.',
      
    ];

    $validator = Validator::make($data, $rules, $messages );

    if ($validator->fails())
      return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

    $evaluation = CompanyEvaluation::find($data['company_evaluation_id']);
    $evaluation->likes()->where("user_id",$user->id)->delete();

    $evaluation->user = $evaluation->user()->get();
    $evaluation->company = $evaluation->company()->get();
    $evaluation->likes = $evaluation->likes()->get();

    return response()->json([ "status" => 1, "evaluation" => $evaluation ]);

  }

}
