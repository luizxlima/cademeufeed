<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class Json
{
    
    public function handle($request, Closure $next)
    {
        if (empty($request->json()->all())) {
            return response()->json(

                [ 

                    "status" => 0,

                    "errors" => [ 
                        
                        'A requisição não é um JSON válido.'

                    ]
                    
                ]

            );
        }

        return $next($request);
    }
}