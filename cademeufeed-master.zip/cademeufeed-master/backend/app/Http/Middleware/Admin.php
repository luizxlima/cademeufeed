<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

use App\Models\User;

class Admin
{
    
    public function handle($request, Closure $next)
    {
        
        $user = User::findOrFail(  $request->get('userId') );

        if ($user->profile != 0) {
            return response()->json(

                [ 

                    "status" => 0,

                    "errors" => [ 
                        
                        'O usuário autenticado precisa ser admin.'

                    ]
                    
                ]

            );
        }

        return $next($request);
    }
}