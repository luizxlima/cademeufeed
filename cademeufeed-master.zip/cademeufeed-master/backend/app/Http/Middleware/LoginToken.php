<?php

namespace App\Http\Middleware;

use Closure;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;

use App\Models\User;

class LoginToken
{
    
    public function handle(Request $request, Closure $next)
    {
        
      $data = json_decode( $request->getContent(), true );

      $rules = [

        'login_token' => 'required',
        
      ];

      $messages = [

        'required' => 'O atributo :attribute é obrigatório.',
       
      ];

      $validator = Validator::make($data, $rules, $messages );

      if ($validator->fails())
        return response()->json([ "status" => 0, "errors" => $validator->errors()->all()]);

      $loginToken = $data["login_token"];
      $decryptedLoginToken;

      try {
        
        $decryptedLoginToken = Crypt::decryptString($loginToken);
      
      } catch (DecryptException $e) {
      
        return response()->json([ "status" => 0, "errors" => [ "Token de autenticação inválido." ] ]);

      }

      $userId = explode( "|", $decryptedLoginToken )[0];

      $user = User::where([ 

        [ "id", $userId ], 

        [ 'login_token', $loginToken ], 
        [ 'login_token_expires_at', ">", now() ], 

      ])->first();

      if( $user == null )
        return response()->json([ "status" => 0, "errors" => [ "Token de autenticação inválido." ] ]);

      $loginTokenExpiresAt = now()->modify('+30 min');
      $user->login_token_expires_at = $loginTokenExpiresAt;

      $user->save();

      $request->attributes->add(['userId' => $userId]);
      return $next($request);

    }
}